const Sdata=[
    {
        sname: "RRR",
        imgscr: "https://m.economictimes.com/thumb/msid-90500113,width-1200,height-900,resizemode-4,imgsize-115038/rrr-box-office-collection.jpg",
        title: "A Netflix Original Series",
        links: "https://www.netflix.com/in/title/81476453"
    },
    {
        sname: "Stranger Things 4",
        imgscr: "https://upload.wikimedia.org/wikipedia/en/7/78/Stranger_Things_season_4.jpg",
        title: "A Netflix Original Series",
        links: "https://www.netflix.com/in/title/80057281"
    },
    {
        sname: "Money Heist",
        imgscr: "https://assets.gadgets360cdn.com/pricee/assets/product/202111/money_heist_season_5_1638276144.jpg",
        title: "A Netflix Original Series",
        links: "https://www.netflix.com/in/title/80192098"
    },
    
    {
        sname: "KGF 2",
        imgscr: "https://www.mirchi9.com/wp-content/uploads/2022/04/KGF-2-MovieReview.jpg",
        title: "Amazon Prime",
        links: "https://www.primevideo.com/detail/0OLFV66669RCQ9BSC7YCWOZA6S/ref=atv_sr_def_c_unkc_1_1_1?sr=1-1&pageTypeIdSource=ASIN&pageTypeId=B09ZQQWQ8S&qid=1655541881"
    },
    {
        sname: "Pushpa:The Rise",
        imgscr: "https://cdn.gulte.com/wp-content/uploads/2021/12/Review1.jpg",
        title: "Amazon Prime",
        links: "https://www.primevideo.com/detail/0QH32UG7NRSFRGZT78NFD6KED7/ref=atv_sr_def_c_unkc_1_1_1?sr=1-1&pageTypeIdSource=ASIN&pageTypeId=B09PR53BZ4&qid=1655541984"
    },
    {
        sname: "Family Man Season 2",
        imgscr: "https://cdn.dnaindia.com/sites/default/files/styles/full/public/2021/06/03/977374-thefamilyman2-streaming.jpg",
        title: "Amazon Prime",
        links: "https://www.primevideo.com/detail/0H3DDB4KBJFNDCKKLHNRLRLVKQ/ref=atv_sr_def_c_unkc_2_1_2?sr=1-2&pageTypeIdSource=ASIN&pageTypeId=B08T76677S&qid=1655542034"
    },
    {
        sname: "Kapil Sharma: I am not done yet",
        imgscr: "https://m.media-amazon.com/images/M/MV5BOGQzOTRkMWMtZDcwNy00ZmFjLTlkYWEtNDMzZmY5NDMxZDQyXkEyXkFqcGdeQXVyNDQ3OTI3Mzk@._V1_FMjpg_UX1000_.jpg",
        title: "A Netflix Original Series",
        links: "https://www.netflix.com/in/title/81386962"
    }
];

export default Sdata;